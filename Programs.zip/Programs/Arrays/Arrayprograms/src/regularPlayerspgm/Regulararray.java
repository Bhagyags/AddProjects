package regularPlayerspgm;

import java.util.Scanner;

public class Regulararray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner Scan=new Scanner(System.in);
		System.out.println("Enter number of teams");
		int row=Scan.nextInt();
		System.out.println("Enter number of players");
		int col1=Scan.nextInt();
		System.out.println("Enter number of players in second row");
		int col2=Scan.nextInt();
		float arr[][]=new float[row][];
		arr[0]=new float[col1];
		arr[1]=new float[col2];
		for(int i=0;i<=arr.length-1;i++)
		{
			for(int j=0;j<=arr[i].length-1;j++)
			{
				System.out.println("Enter the height of team "+(i+1)+ " player "+(j+1));
				arr[i][j]=Scan.nextFloat();
			}
		}
		for(int i=0;i<=arr.length-1;i++)
		{
			for(int j=0;j<=arr[i].length-1;j++)
			{
				System.out.println("The height of team "+(i+1)+ " player "+(j+1)+ " is " +arr[i][j]);
			}
		}
	}

}
