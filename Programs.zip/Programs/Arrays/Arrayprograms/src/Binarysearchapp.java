
public class Binarysearchapp {

	public static void binaerySearch(int[]arr,int key) {
		int low=0;
		int high=arr.length-1;
		int mid=(low+high)/2;
        if(key==arr[mid])
        {
        	System.out.println("key "+key+" is found at index "+mid);
        }
        else if(key>arr[mid])
        {
        	low=mid+1;
        	high=high;
        }
        else {
        	low=low;
        	high=mid-1;
        }
	System.out.println("key "+key+ " is not found");
	}
}
