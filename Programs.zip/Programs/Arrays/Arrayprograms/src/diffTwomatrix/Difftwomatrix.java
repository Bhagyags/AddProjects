package diffTwomatrix;

import java.util.Scanner;

public class Difftwomatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner Scan=new Scanner(System.in);
	    System.out.println("Enter the number of rows and columns in matrix 1 and matrix 2");
	    int row=Scan.nextInt();
	    int col=Scan.nextInt();
				int [][]mat1=new int[row][col];
				int [][]mat2=new int[row][col];
				int [][]resMatrix=new int[row][col];				
				System.out.println("Enter the elements stored in matrix 1");
				for(int i=0;i<=mat1.length-1;i++)
			    {   
					for(int j=0;j<=mat1[i].length-1;j++)
					{
					mat1[i][j]=Scan.nextInt();
					}
				}
			   for(int i=0;i<=mat1.length-1;i++)
			   {   
				for(int j=0;j<=mat1[i].length-1;j++)
				{
			       System.out.print(mat1[i][j]+" ");
			    }
			     System.out.println();
	           }
			   System.out.println("Enter the elements stored in matrix 2");
			   for(int i=0;i<=mat2.length-1;i++)
			   {   
				for(int j=0;j<=mat2[i].length-1;j++)
				{
				mat2[i][j]=Scan.nextInt();
				}
			   }
			   for(int i=0;i<=mat2.length-1;i++)
			   {   
				for(int j=0;j<=mat2[i].length-1;j++)
				{
					System.out.print(mat2[i][j]+" ");
				}
				System.out.println();
			   }
			   for(int i=0;i<=resMatrix.length-1;i++)
			   {   
				for(int j=0;j<resMatrix[i].length-1;j++)
				{
				resMatrix[i][j]=mat1[i][j]-mat2[i][j];
				}
			   }
			   for(int i=0;i<=resMatrix.length-1;i++)
			   { 
				for(int j=0;j<=resMatrix[i].length-1;j++)
				{
					System.out.print(resMatrix[i][j]+" ");
				}
			   
			   System.out.println(); 
			   }	
	}
}

