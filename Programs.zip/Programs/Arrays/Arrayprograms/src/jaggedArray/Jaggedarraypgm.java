package jaggedArray;

import java.util.Scanner;

public class Jaggedarraypgm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
		Scanner Scan=new Scanner(System.in);
	   //asking the user to enter the company name
	   System.out.println("Enter the name of the company ");
	   int row=Scan.nextInt();
	   String[][] arr=new String[row][];
	   {
		   for(int i=0;i<=arr.length-1;i++)
		   {
			 System.out.println("Enter the number of employees in company "+(i+1));
			 int col=Scan.nextInt(); 
			 arr[i]=new String[col];
		   }
		   for(int i=0;i<=arr.length-1;i++)
		   {
			   for(int j=0;i<=arr[i].length-1;j++)
			   {
				System.out.println("Enter the number of employees"+(i+1)+ "company is "+(j+1));
				arr[i][j]=Scan.next();
			   }
		   }
		   for(int i=0;i<=arr.length-1;i++)
		   {
			   for(int j=0;i<=arr[i].length-1;j++)
			   {
				System.out.println("The name of the company is "+(i+1)+ "employees "+(j+1)+"is" +arr[i][j]);
	   }
	}
	   }
	}
}
