
public class Linearsearchapp {

	public static String linearSearch(int[] arr,int key) {
		for(int i=0;i<=arr.length-1;i++)
        {
	      if(key==arr[i])
	      {
	         return("Key "+key+ " is found at index "+i);
	      }
        }
		     return("Key "+key+ " is not found");
        }
}
