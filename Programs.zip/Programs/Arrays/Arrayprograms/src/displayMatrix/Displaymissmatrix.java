package displayMatrix;

import java.util.Scanner;

public class Displaymissmatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
				Scanner Scan=new Scanner(System.in);
				System.out.println("Enter the number of rows and columns");
				int [][]arr=new int[Scan.nextInt()][Scan.nextInt()];
				System.out.println("Enter the elements stored in array");
			   for(int i=0;i<=arr.length-1;i++)
			   {
				for(int j=0;j<=arr[i].length-1;j++)
				{
					arr[i][j]=Scan.nextInt();
				}
			   }
			   for(int i=0;i<=arr.length-1;i++)
			   {
				for(int j=0;j<=arr[i].length-1;j++)
				{
					if(i==0 || j==0 || i==arr.length-1 || j==arr[i].length-1)
					   {
					   System.out.print(arr[i][j]+" ");
				       }
					   else				   
					   {
				         System.out.print("  "); 
			         
					   }
				}
				System.out.println();
			   } 
			}
	

}
