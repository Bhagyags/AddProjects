import java.util.Scanner;

public class Linearsearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner Scan=new Scanner(System.in);
     System.out.println("Enter the size of an array");
     int size=Scan.nextInt();
     int arr[]=new int[size];
     System.out.println("Enter "+arr.length+" elements to be stored in array");
     for(int i=0;i<=arr.length-1;i++)
     {
    	 arr[i]=Scan.nextInt();
     }
     System.out.println("Enter the key to be searched");
     int key=Scan.nextInt();
     System.out.println(Linearsearchapp.linearSearch(arr,key));
	}

}
