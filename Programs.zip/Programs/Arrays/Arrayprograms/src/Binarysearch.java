import java.util.Scanner;

public class Binarysearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner Scan=new Scanner(System.in);
      System.out.println("Enter the size of array");
      int arr[]=new int[Scan.nextInt()];
      System.out.println("Enter "+arr.length+" elements to be stored in an array");
      for(int i=0;i<=arr.length-1;i++)
      {
    	  arr[i]=Scan.nextInt();
      }
      System.out.println("Enter Key to be searched");
      int key=Scan.nextInt();
      Binarysearchapp.binaerySearch(arr,key);
	}

}
