package mergeArray;
import java.util.Arrays;

public class Mergearray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr1={1,2,3,4,5};
		int[] arr2={6,7,8,9,10};
		int length=arr1.length+arr2.length;
		int[] merge=new int[length];
		int pos=0;
		for(int element:arr1)
		{
			merge[pos]=element;
			pos++;
		}
		for(int element:arr2)
		{
			merge[pos]=element;
			pos++;
		}
		System.out.println(Arrays.toString(merge));
	}

}
