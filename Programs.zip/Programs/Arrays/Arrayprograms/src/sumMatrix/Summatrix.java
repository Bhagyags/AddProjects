package sumMatrix;

import java.util.Scanner;

public class Summatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
		int sum=0;
		Scanner Scan=new Scanner(System.in);
	    System.out.println("Enter the number of rows and columns");
				int [][]arr=new int[Scan.nextInt()][Scan.nextInt()];
				System.out.println("Enter the elements stored in array");
			   for(int i=0;i<=arr.length-1;i++)
			   {   
				for(int j=0;j<=arr[i].length-1;j++)
				{
					arr[i][j]=Scan.nextInt();
				}
			   }
			   for(int i=0;i<=arr.length-1;i++)
			   {  
				for(int j=0;j<=arr[i].length-1;j++)
				{
					sum=sum+arr[i][j];
				}
			   }
			   System.out.println("sum of all elemets is "+sum); 
			}
	
}
