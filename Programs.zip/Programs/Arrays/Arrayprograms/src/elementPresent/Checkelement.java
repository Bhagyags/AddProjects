package elementPresent;

import java.util.Scanner;

public class Checkelement {

	public static void main(String[] args) {
		int[] arr={1,2,3,4,5};
       //asking the user to enter the number
	    System.out.println("Enter the numbers");
	    
	    
	    	
	    	System.out.println("The numbers are:"+arr.length);	
	    }
	    
	
}
