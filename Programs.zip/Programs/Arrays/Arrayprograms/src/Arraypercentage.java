import java.util.Scanner;

public class Arraypercentage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner Scan=new Scanner(System.in);
System.out.println("Enter the number of subjects");
int n=Scan.nextInt();
String[] arr=new String[n];
for(int i=0;i<=arr.length-1;i++)
{
System.out.println("Enter the name of subject-" + (i+1));
	arr[i]=Scan.next();
}
for(int i=0;i<=arr.length-1;i++)
{
System.out.println("The name of subject-"+(i+1) +" is ");
	System.out.println(arr[i]+" ");
}
	}

}
