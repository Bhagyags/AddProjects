package com.kodnest.array.sorting;

import java.util.Scanner;

public class Bubblesortapp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner Scan=new Scanner(System.in);
      System.out.println("Enter the size of array");
      int arr[]=new int[Scan.nextInt()];
      System.out.println("Enter "+arr.length+" elements to be stored in an array");
      for(int i=0;i<=arr.length-1;i++)
      {
    	  arr[i]=Scan.nextInt();
      }
      //Displaying the elements before sorting
      System.out.println("Enter the elements before sorting: ");
      for(int i=0;i<=arr.length-1;i++)
      {
    	 System.out.print(arr[i]+" "); 
      }
      System.out.println();
      //Displaying the elements after sorting
      int []sortedarr=Bubblesort.bubbleSort(arr);
      System.out.println("Enter the elements after sorting: ");
      for(int i=0;i<=sortedarr.length-1;i++)
      {
    	 System.out.print(sortedarr[i]+" ");
      }
      System.out.println();
	}
	

}
