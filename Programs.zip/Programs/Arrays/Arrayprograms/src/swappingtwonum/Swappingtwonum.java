package swappingtwonum;

import java.util.Scanner;

public class Swappingtwonum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner Scan=new Scanner(System.in);
		System.out.println("Enter the value of num1");
		int num1=Scan.nextInt();
		System.out.println("Enter the value of num2");
		int num2=Scan.nextInt();
        System.out.println("Elements before swapping "+num1+" "+num2);
        int temp;
        temp=num1;
        num1=num2;
        num2=temp;
        System.out.println("Elements After swapping "+num1+" "+num2);
	}

}
