package liftPgm;

import java.util.Scanner;

public class Liftprogramarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner Scan=new Scanner(System.in);
      float sum=0;
      int arr[]=new int[10];
      System.out.println("Enter the weight");

      for(int i=0;i<=arr.length-1;i++)
       {
    	  arr[i]=Scan.nextInt();	
       }
      for(int i=0;i<=arr.length-1;i++)
       {
    	  sum+=arr[i];
       }
      System.out.println(sum);
       if(sum>800)
       {
	      System.out.println("Lift not work");
       }
       else 
       {
	     System.out.println("Lift will work");
       }
     }
	

}
