import java.util.Scanner;

public class Swapindex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner Scan=new Scanner(System.in);
     System.out.println("Enter the size of an array");
		int size=Scan.nextInt();
		int arr[]=new int[size];
		System.out.println("Enter " +arr.length+ " elemnts to be stored in array");
		for(int i=0;i<=arr.length-1;i++)
		{
			arr[i]=Scan.nextInt();
		}
		System.out.println("Enter 2 indexes to be swappes");
		int i1=Scan.nextInt();
		int i2=Scan.nextInt();
		int temp;
		System.out.println("The array elements before swapping are: ");
		for(int i=0;i<=arr.length-1;i++)
		{
		System.out.print(arr[i]+" ");
		}
		System.out.println();
		if(i1>0 && i1<=arr.length-1 && i2>0 && i2<=arr.length-1)
		{
		temp=arr[i1];
		arr[i1]=arr[i2];
		arr[i2]=temp;
		}
		else {
			System.out.println("Enter the indexes in the range of 0 to "+(arr.length-1));
		}
	System.out.println("Elements after swapping in array: ");
	for(int i=0;i<=arr.length-1;i++)
	{
	System.out.print(arr[i]+" ");
	}
}
}
