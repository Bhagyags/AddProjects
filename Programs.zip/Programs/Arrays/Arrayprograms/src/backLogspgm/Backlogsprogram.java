package backLogspgm;

import java.util.Scanner;

public class Backlogsprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner Scan=new Scanner(System.in);
		System.out.println("Enter the number of semester");
		int n=Scan.nextInt();
		String[] arr=new String[n];
		for(int i=0;i<=arr.length-1;i++)
		{
		System.out.println("is there any backlogs in semester-" + (i+1));
		boolean res=Scan.nextBoolean();
		if(res==true)
		{
			arr[i]="Yes";
		}
		else {
			arr[i]="No";
		}
		}
		for(int i=0;i<=arr.length-1;i++)
		{
		System.out.println("The backlogs in semester-"+(i+1) +" is ");
			System.out.println(arr[i]+" ");
		}
	}	
}
