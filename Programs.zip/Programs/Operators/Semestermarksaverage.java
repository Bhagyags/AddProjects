import java.util.Scanner;

public class Semestermarksaverage {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the First number");
		int a=scan.nextInt();
		System.out.println("Enter the second number");
		int b=scan.nextInt();
		System.out.println("Enter the third number");
		int c=scan.nextInt();
		System.out.println("Enter the fourth number");
		int d=scan.nextInt();
		System.out.println("Enter the Fifth number");
		int e=scan.nextInt();
		System.out.println("Enter the sixth number");
		int f=scan.nextInt();
		System.out.println("Enter the seventh number");
		int g=scan.nextInt();
		System.out.println("Enter the eighth number");
		int h=scan.nextInt();
		int result=calculateaverage(a,b,c,d,e,f,g,h);
		System.out.println("semester average result is"+result);
		
	}
	public static int calculateaverage(int i,int j, int k,int l, int m,int n,int o,int p)
	{
	return (i+j+k+l+m+n+o+p)/8;
}
}
