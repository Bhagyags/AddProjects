import java.util.Scanner;

public class Powerofsquare {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number");
		int a=scan.nextInt();
		int result=powersquare(a);
		System.out.println("The square result is "+result);

	}
	public static int powersquare(int x)
	{
	return (x*x);
	}
}
