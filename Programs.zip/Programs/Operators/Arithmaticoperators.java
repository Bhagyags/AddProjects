import java.util.Scanner;

public class Arithmaticoperators {
public static void main(String []args)
{
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter the First number");
	int a=scan.nextInt();
	System.out.println("Enter the second number");
	int b=scan.nextInt();
	int res1=subtract(a,b);
	System.out.println("substraction result is"+res1);
	int res2=multiplication(a,b);
	System.out.println("multiplication result is"+res2);
	double res3=division(a,b);
	System.out.println("division result is"+res3);
	int res4=remainder(a,b);
	System.out.println("Remainder result is"+res4);
}
	public static int subtract(int num1,int num2)
	{
		return num1-num2;
	}
	public static int multiplication(int num1,int num2)
	{
		return num1*num2;
	}
	public static double division(int num1,int num2)
	{
		return num1/num2;
	}
	public static int remainder(int num1,int num2)
	{
		return num1%num2;
	}
}

