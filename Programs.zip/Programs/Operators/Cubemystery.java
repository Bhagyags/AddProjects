import java.util.Scanner;

public class Cubemystery {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number");
		int a=scan.nextInt();
		int result=cube(a);
		System.out.println("The cube result is "+result);
	}
	public static int cube(int x)
	{
	return (x*x*x);
	}

}
