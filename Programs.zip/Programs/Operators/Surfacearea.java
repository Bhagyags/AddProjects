import java.util.Scanner;

public class Surfacearea {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the value of radius");
		double x=scan.nextDouble();
	    double res=calculatesurfacearea(x);
		System.out.println("Surface area "+res);
		
	}
	public static double calculatesurfacearea(double num1)
	{
		return 4*3.142*(num1*num1);
	}

}
