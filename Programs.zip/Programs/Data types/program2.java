class program2
{
public static void main (String []args)
{
float x=24.37F;
System.out.println("The value of x is " +x);
double y=432.364578;
System.out.println("The value of y is " +y);
}
}