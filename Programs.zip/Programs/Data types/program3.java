class program3
{
public static void main (String []args)
{
boolean isplaced=false;
System.out.println("The value isplaced is " +isplaced);
boolean ismarreid=true;
System.out.println("The value ismarreid is " +ismarreid);
}
}