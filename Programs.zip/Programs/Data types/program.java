class program
{
public static void main (String []args)
{
byte age=22;
System.out.println("The age is" + age);
short year=2023;
System.out.println("The year is" + year);
int salary=45000;
System.out.println("The salary is" + salary);
long population=98765432198L;
System.out.println("The population is" + population);
}
}