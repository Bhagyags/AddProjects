
public class Gcdnumbersapp {

	public static void getGcd(int a,int b) {
		// TODO Auto-generated method stub
		int gcd=0;
while(b!=0)
{
	if(a>b)
	{
		a=a-b;
	}
	else {
		b=b-a;
		System.out.println("GCD of"+a);	
}
	}
}
}
