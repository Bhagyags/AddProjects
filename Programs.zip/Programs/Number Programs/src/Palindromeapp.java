
public class Palindromeapp {

	public static void getPalindrome(int num) {
		// TODO Auto-generated method stub
		int reversednum=0,remainder;
		int originalnum=num;
		while(num!=0) {
			remainder=num%10;
			reversednum=reversednum*10+remainder;
			num/=10;
		}
		if(originalnum==reversednum) {
			System.out.println(originalnum+ " is palindrome");
		}
		else {
			System.out.println(originalnum+ " is not palindrome");
		}
		
}
}
