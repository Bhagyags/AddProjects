package cubeRoot;

public class Cuberootapp {

	public static void getCube(int num) {
		// TODO Auto-generated method stub
		double res=Math.cbrt(num);
		System.out.println("cube of "+num+" is: " +res);
	}

}
