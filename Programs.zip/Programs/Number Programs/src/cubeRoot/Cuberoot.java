package cubeRoot;

import java.util.Scanner;

import squareRoot.Squarerootapp;

public class Cuberoot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
				Scanner Scan=new Scanner(System.in);
			   //asking the user to enter the number
			   System.out.println("Enter the number");
			   int num=Scan.nextInt();
			   Cuberootapp.getCube(num);
	}

}
