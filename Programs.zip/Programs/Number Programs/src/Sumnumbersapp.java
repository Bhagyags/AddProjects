
public class Sumnumbersapp {

	public static void getSum(int n) {
		// TODO Auto-generated method stub
		int sum=0;
for(int i=1;i<=n;i++)
{
	sum=sum+i;
		System.out.println("Sum of first natural numbers is "+sum);
	}
}
}
