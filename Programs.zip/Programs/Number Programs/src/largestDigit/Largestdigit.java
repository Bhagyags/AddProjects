package largestDigit;

import java.util.Scanner;

import sumSquare.Sumsquareapp;

public class Largestdigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
				Scanner Scan=new Scanner(System.in);
			   //asking the user to enter the number
			   System.out.println("Enter the number");
			   int num=Scan.nextInt();
			   Largestdigitapp.getDigit(num);
		}
	}
