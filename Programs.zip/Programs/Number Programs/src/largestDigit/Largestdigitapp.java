package largestDigit;

public class Largestdigitapp {

	public static void getDigit(int n) {
		// TODO Auto-generated method stub
int l=0,d=0;
while (n!=0){
	d=n%10;
	if(d>1) {
		l=d;
	}
	n/=10;
}
System.out.println("The largest digit "+l);
	}

}
