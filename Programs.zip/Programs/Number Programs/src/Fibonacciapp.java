
public class Fibonacciapp {

	public static void getFibonacci(int n) {
		// TODO Auto-generated method stub
		int firstterm=0,secondterm=1;
		System.out.println("Fibonacci series till"+n+ "terms:");
		for(int i=1;i<=n;i++) {
			System.out.println(firstterm+" ");
			int nextterm=firstterm+secondterm;
			firstterm=secondterm;
			secondterm=nextterm;
	}

	}

}

