import java.util.Scanner;

public class Swap {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the value of X");
		int x=scan.nextInt();
		System.out.println("Enter the value of y");
		int y=scan.nextInt();
		swap(x,y);
		
		
	}
	static void swap(int a,int b)
	{
		int temp;
		System.out.println("Before swapping "+a+ ""+b);
		System.out.println("After swapping "+b+ ""+a);
		temp=a;
		a=b;
		b=temp;
	}
	

}
