
public class Displaynumbersapp {

	public static void getDiv(int n) {
		// TODO Auto-generated method stub
		
		for(int i=1;i<=n;i++) {
if(i%2==0)
{
	System.out.print(i+",");
}
}
	}
public static void getDivthree(int n)
		{
			for(int i=1;i<=n;i++) {
				if(i%3==0)
				{
					System.out.print("The numbers divisuble by 3 is "+i+",");
					
				}
		}
}
public static void getDivfive(int n)
{
	for(int i=1;i<=n;i++) {
		if(i%5==0)
		{
			System.out.println("The numbers divisuble by 5 is "+i+",");
			
		}
}
}
public static void getDivboth(int n)
{
	for(int i=1;i<=n;i++) {
		if(i%2==0 && i%5==0)
		{
			System.out.println("The numbers divisuble by both 2 and 5 is "+i+",");
			
		}
}
}
public static void getDivboththree(int n)
{
	for(int i=1;i<=n;i++) {
		if(i%3==0 && i%5==0)
		{
			System.out.print("The numbers divisuble by both 3 and 5 is "+i+",");
			
		}
}
}
public static void getDivprime(int n)
{
	for(int i=1;i<=n;i++) {
		int count=0;
		for(int j=2;j<=i;j++) {	
		if(i%j==0)
		{
			count++;
		}
		}
		if(count==1)
		{
			System.out.println(i+" ");
}
}
}
public static void getDiveven(int n)
{
	for(int i=1;i<=n;i++) {
		if(i%3==0)
		{
			if(i%2==0)
		{
			System.out.print("The numbers divisuble by 3 and even numbers is "+i+",");
			
		}
}
	}
}
public static void getDivfieven(int n)
{
	for(int i=1;i<=n;i++) {
		if(i%5==0)
		{
			if(i%2!=0)
		{
			System.out.println("The numbers divisuble by 5 and odd number is "+i+",");
			
		}
}
}
}
public static void getPrimeeven(int n)
{
	for(int i=1;i<=n;i++) {
		int count=0;
		for(int j=2;j<=i;j++) {	
		if(i%j==0 && i%2==0)
		{
			count++;
		}
		}
		if(count==1)
		{
			System.out.println(i+" ");
}
}
}
public static void getPrimeodd(int n)
{
	for(int i=1;i<=n;i++) {
		int count=0;
		for(int j=2;j<=i;j++) {	
		if(i%j==0 && i%2!=0)
		{
			count++;
		}
		}
		if(count==1)
		{
			System.out.println(i+" ");
}
}
}
}



