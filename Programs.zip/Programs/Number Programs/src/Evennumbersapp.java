
public class Evennumbersapp {

	public static void getEven(int n) {
		// TODO Auto-generated method stub
for(int i=1;i<=n;i++)
{
	if(i%2==0)
	{
		System.out.println("All the even numbers "+i);
	}
}
	}

}
