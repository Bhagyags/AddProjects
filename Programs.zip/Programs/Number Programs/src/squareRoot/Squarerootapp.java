package squareRoot;

public class Squarerootapp {

	public static void getSquare(int num) {
		// TODO Auto-generated method stub
		double res=Math.sqrt(num);
System.out.println("square of "+num+" is: " +res);
	}
}
