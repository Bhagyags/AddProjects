import java.util.Scanner;

public class Addition {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the First number ");
		long a=scan.nextLong();
		System.out.println("Enter the second number");
		long b=scan.nextLong();
		System.out.println(addition(a,b));
	}
		public static long addition(long num1,long num2)
		{
		return num1+num2;
	    }

}
