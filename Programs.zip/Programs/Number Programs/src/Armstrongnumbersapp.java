
public class Armstrongnumbersapp {

	public static void getArmstrong(int num) {
		// TODO Auto-generated method stub
int originalnum,remainder=0,result=0,n=0;
originalnum=num;
while(originalnum!=0)
{
	remainder=originalnum%10;
	result+=Math.pow(remainder,n);
	originalnum/=10;
}
if(result==num)
{
	System.out.println(num+ " is an armstrong number");
}
else {
	System.out.println(num+ " is not an armstrong number");
}
	}
	
}
