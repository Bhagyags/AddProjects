
public class Factorialapp {

	public static void getFactorial(int num) {
		// TODO Auto-generated method stub
		long fact=1;
		for(int i=1;i<=num;i++)
		{
			fact*=i;
				System.out.println("factorial number is"+fact);
			}
		}

	}


