package frequencyDigit;

public class Frequencydigitapp {

	public static void getFrequency(int num) {
		// TODO Auto-generated method stub
int count,digit,temp;
for(int i=0;i<=num;i++)
{
	count=0;
	temp=num;
	while(temp>0)
	{
		digit=temp%10;
		if(digit==i)
		{
			count++;
		}
		temp/=10;
	}
	if(count>0)
	{
		System.out.println(i+"\t" +count);
	}
}
	}

}
