package sumSingledigit;

import java.util.Scanner;

import productOddnum.Productoddnumapp;

public class Sumsingledigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
				Scanner Scan=new Scanner(System.in);
			   //asking the user to enter the number
			   System.out.println("Enter the number");
			   int num=Scan.nextInt();
			   Sumsingledigitapp.getSingle(num);
	}

}
