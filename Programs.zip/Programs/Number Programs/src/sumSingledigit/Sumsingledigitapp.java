package sumSingledigit;

public class Sumsingledigitapp {

	public static void getSingle(int n) {
		// TODO Auto-generated method stub
int sum=0;
while(n>0 || sum>9)
{
	if(n==0) {
		n=sum;
		sum=0;
	}
	sum+=n%10;
	n/=10;
}
System.out.println("The sum of digits "+sum);
	}

}
//adding the given number after addition become two digit again it will add example 6543=18 again 
//1+8=9
