package sumSquare;

public class Sumsquareapp {

	public static void getSquare(int num) {
		// TODO Auto-generated method stub
int sum=0;
for(int i=1;i<=num;i++)
{
	sum=sum+i*i;
}
System.out.println(sum);
	}

}
