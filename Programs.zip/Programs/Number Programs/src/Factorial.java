import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
				Scanner Scan=new Scanner(System.in);
			   //asking the user to enter the number
			   System.out.println("Enter the number");
			   int x=Scan.nextInt();
			   Factorialapp.getFactorial(x);
			}
	}

