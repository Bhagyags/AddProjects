import java.util.Scanner;

public class Displaynumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
		Scanner Scan=new Scanner(System.in);
	   //asking the user to enter the number
	   System.out.println("Enter the number");
	   int x=Scan.nextInt();
	   Displaynumbersapp.getDiv(x);
	   Displaynumbersapp.getDivthree(x);
	   Displaynumbersapp.getDivfive(x);
	   Displaynumbersapp.getDivboth(x);
	   Displaynumbersapp.getDivboththree(x);
	   Displaynumbersapp.getDivprime(x);
	   Displaynumbersapp.getDiveven(x);
	   Displaynumbersapp.getDivfieven(x);
	   Displaynumbersapp.getPrimeeven(x);
	   Displaynumbersapp.getPrimeodd(x);
	   
	}

}
