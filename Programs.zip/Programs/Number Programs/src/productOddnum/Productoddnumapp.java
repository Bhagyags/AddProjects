package productOddnum;

public class Productoddnumapp {

	public static void getProduct(int num) {
		// TODO Auto-generated method stub
		int product=1;
for(int i=1;i<=num;i++)
{
	if(i%2!=0)
	{
		product*=i;
	}
}
	System.out.println("The product of odd numbers "+product);
}
	

}
