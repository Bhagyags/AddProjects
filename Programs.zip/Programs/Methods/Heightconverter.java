import java.util.Scanner;

public class Heightconverter {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the value");
		double x=scan.nextDouble();
		double res=convertInchestofeet(x);
		System.out.println("Convert inches to feet "+res);

}
	public static double convertInchestofeet(double num1)
	{
		return num1/12;
	}
}
