import java.util.Scanner;

public class Plotarea {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the side");
		int a=scan.nextInt();
		int res=calculateplotarea(a);
		System.out.println("The area calculated is "+res);

}
	public static int calculateplotarea(int x)
	{
		return x*x;
	}
}
