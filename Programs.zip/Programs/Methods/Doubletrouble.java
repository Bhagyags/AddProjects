import java.util.Scanner;

public class Doubletrouble {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number");
		int a=scan.nextInt();
		int res=doubleTheNumber(a);
		System.out.println("The result of doubling the number "+res);
	}
	public static int doubleTheNumber(int num1)
	{
		return num1*2;
	}

}
