import java.util.Scanner;

public class Halvenumber {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number");
		double a=scan.nextDouble();
		double res=halvethenumber(a);
		System.out.println("Convert inches to feet "+res);

}
	public static double halvethenumber(double num)
	{
		return num/2;
	}
}
