import java.util.Scanner;

public class Secretmessagedecoder {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the character");
		char a=scan.next().charAt(0);
		int result=messageDecoder(a);
		System.out.println("The message decoder is "+result);
	}
	public static int messageDecoder(int x)
	{
		
		return x;
		
	}

}
