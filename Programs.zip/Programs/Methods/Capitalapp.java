
public class Capitalapp {
public static void getCapital(char ch)
{
    //Checking whether the character is upper case
        if(ch>='A' && ch<='Z')
        {
        	System.out.println("Capital Letter");
        }
}
}
