import java.util.Scanner;

public class Thrustcontrol {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number");
		int a=scan.nextInt();
		long res=calculatethrust(a);
		System.out.println("Resulting thrust is "+res);

}
	public static long calculatethrust(int throttlesetting)
	{
		return (throttlesetting*throttlesetting*throttlesetting*throttlesetting*throttlesetting);
	}
}