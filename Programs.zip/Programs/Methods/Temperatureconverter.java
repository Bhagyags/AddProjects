import java.util.Scanner;

public class Temperatureconverter {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Fahrenheit");
		float a=scan.nextFloat();
		double result=temperatureconverter(a);
		System.out.println("Temperature convert result is"+result);
		}
	public static float temperatureconverter(float x)
	{
	return (x-32)*5/9;
	}

}
