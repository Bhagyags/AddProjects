import java.util.Scanner;

public class Capitalletter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner Scan=new Scanner(System.in);
		System.out.println("Enter the chracter");
		char ch=Scan.next().charAt(0);
		Capitalapp.getCapital(ch);
	}

}
