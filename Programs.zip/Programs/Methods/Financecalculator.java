import java.util.Scanner;

public class Financecalculator {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the principal value");
		double a=scan.nextDouble();
		System.out.println("Enter the rate value");
		double b=scan.nextDouble();
		System.out.println("Enter the time value");
		double c=scan.nextDouble();
	    double res=calculatesimpleinterest(a,b,c);
		System.out.print("The simple interest is" +res);
	}
	public static double calculatesimpleinterest(double principal,double rate, double time)
	{
		return (principal*rate*time);
	}

}
