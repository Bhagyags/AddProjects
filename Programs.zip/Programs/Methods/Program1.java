package program;

public class Program1 {
	public static void main(String []args)
	{
		display();
	}
public static void display()
{
	System.out.println("Inside display");
}
}
