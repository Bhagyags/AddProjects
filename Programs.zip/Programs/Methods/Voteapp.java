
public class Voteapp {
public static void votemsg(int age)
{
	if(age>=18)
	{
		System.out.println("Vote eligible");
	}
}
}
