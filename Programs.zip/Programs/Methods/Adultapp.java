
public class Adultapp {
public static void getmsg(int age)
{
	if(age>=21)
	{
		System.out.println("Adult");
	}
}
}
