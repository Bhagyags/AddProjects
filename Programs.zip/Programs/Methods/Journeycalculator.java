import java.util.Scanner;

public class Journeycalculator {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the speed");
		double a=scan.nextDouble();
		System.out.println("Enter the time");
		double b=scan.nextDouble();
		double result=calculatedistance(a,b);
		System.out.println("substraction result is"+result);
	}
	public static
	double calculatedistance(double speed,double time)
	{
		return speed*time;
	}


}
