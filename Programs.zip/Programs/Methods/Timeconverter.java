import java.util.Scanner;

public class Timeconverter {
	public static void main(String []args)
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the hour");
		double a=scan.nextDouble();
		System.out.println("Enter the minute");
		int b=scan.nextInt();
		double res=converttohours(a,b);
		System.out.println("Convert inches to feet "+res);

}
	public static double converttohours(double x,int y)
	{
		return x/y;
	}
}
