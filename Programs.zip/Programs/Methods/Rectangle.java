import java.util.Scanner;

public class Rectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
				Scanner Scan=new Scanner(System.in);
			   //asking the user to enter the length
			   System.out.println("Enter the length");
			   double x=Scan.nextDouble();
			   System.out.println("Enter the width");
			   double y=Scan.nextDouble();
			   double res=Rectanglearea(x,y);
				System.out.println("Calculate rectangle area "+res);
			   		   
	}
	public static double Rectanglearea(double l,double w)
	{
		return l*w;
	}
}

