import java.util.Scanner;

public class Stringjoiner {
		public static void main(String []args)
		{
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter the First String");
			String a=scan.next();
			System.out.println("Enter the second String");
			String b=scan.next();
			String res=add(a,b);
			System.out.println("joinStrings "+res);
		}
		public static String add(String str1,String str2)
		{
			return str1+str2;
		}





}
