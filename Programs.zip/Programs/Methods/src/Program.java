
public class Program {
	public String display(String a)
	{
		return a;
	}

}
