
public class Program3 {
	public static String display(String a)
	{
       return a;
	}
}
