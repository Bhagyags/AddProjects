
public class Program2 {
	public static void main(String []args)
	{
		Program2 P=new Program2();
		P.display();
}
	public void display()
	{
		System.out.println("Inside display");
	}
}
