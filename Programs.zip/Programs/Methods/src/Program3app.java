
public class Program3app {
		public static void main(String []args)
		{
		String S="Inside display";
		System.out.println(Program3.display(S));
		}
	}

