
public class Programapp {
	public static void main(String []args)
	{
	Program P=new Program();
	System.out.println(P.display("inside display"));
	}
}
