class program4
{
public static void main (String []args)
{
byte a=97;
char b=(char)a;
System.out.println(a);
System.out.println(b);
}
}