class Programs
{
public static void main(String []args)
{
int a=10 , b=20;
float p=10.5F , q=20.5F;
double m=100.5 , n=200.5;
System.out.println(add(p,q));
}
public static int add(float x , double y)
{
return x+y;
}
public static double add(double x , float y)
{
return x+y;
}
}
                            