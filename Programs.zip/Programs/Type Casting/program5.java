import java.util.Scanner;
class program5
{ 
public static void main (String []args)
{
Scanner scan=new Scanner(System.in);
System.out.println("Enter the byte value");
byte a=scan.nextByte();
System.out.println("Enter the short value");
short b=scan.nextShort();
System.out.println("Enter the int value");
int c=scan.nextInt();
System.out.println("Enter the long value");
long d=scan.nextLong();
System.out.println("Enter the float value");
float e=scan.nextFloat();
System.out.println("Enter the double value");
double f=scan.nextDouble();
System.out.println("Enter the boolean value");
boolean g=scan.nextBoolean();
System.out.println("The value of a is "+a);
System.out.println("The value of b is "+b);
System.out.println("The value of c is "+c);
System.out.println("The value of d is "+d);
System.out.println("The value of e is "+e);
System.out.println("The value of f is "+f);
System.out.println("The value of g is "+g);
}
}

