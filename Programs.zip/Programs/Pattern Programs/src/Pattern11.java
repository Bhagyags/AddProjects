import java.util.Scanner;

public class Pattern11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
	    Scanner Scan=new Scanner(System.in);
	    //asking the user to enter the number
	    System.out.println("Enter the value ");
	    int n=Scan.nextInt();
	     System.out.println("Enter the character need to be printed");
	     char ch=Scan.next().charAt(0);
			   //using for loop
		for(int i=1;i<=n;i++)
			   {
				   for(int j=1;j<=n-i+1;j++)
				   {
					   System.out.print(" ");
				   }
				   for(int j=1;j<=2*i-1;j++)
				   {
				   System.out.print(ch); 
			   }
				   System.out.print("\n"); 
			}
	}
	}
