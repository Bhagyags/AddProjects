import java.util.Scanner;

public class Pattern20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
	    Scanner Scan=new Scanner(System.in);
	    //asking the user to enter the number
	    System.out.println("Enter the value ");
	    int n=Scan.nextInt();
	    int value=1;
			   //using for loop
		for(int i=1;i<=n;i++)
			   {
				   for(int j=1;j<=n;j++)
				   {
					   System.out.print(value +" ");
					   value++;
			   }
				   System.out.print("\n"); 
			}
	}

}
