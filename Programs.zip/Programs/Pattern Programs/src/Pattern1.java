
public class Pattern1 {

	public static void main(String[] args) {
		/*using for loop
		// TODO Auto-generated method stub
for(int i=1;i<=5;i++)
{
		System.out.print("*");
	}
}*/ /*using while loop
		int i=1;
		while(i<=5)
		{
			System.out.print("*");
			i++;
		}
}*/
		//using do while loop
		int i=1;
		do
		{
			System.out.print("*");
			i++;
		}
		while(i<=5);
		
}
}
