import java.util.Scanner;

public class Pattern23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
	    Scanner Scan=new Scanner(System.in);
	    //asking the user to enter the number
	    System.out.println("Enter the value ");
	    int n=Scan.nextInt();
	    int evencount=2;
	    int oddcount=1;
			   //using for loop
		for(int i=1;i<=n/2;i++)
		{
		 for(int j=1;j<=n;j++)
		  {
			if(evencount<=9) 
			{
			  System.out.print("0" +evencount +" ");
			    evencount+=2;
			   }
				else if(oddcount%2!=0 && oddcount<=9 ){
						   System.out.print("0" +oddcount++ +" ");
						   oddcount+=2;
					   }
					   else {
						   System.out.print(oddcount++ +" ");
					   }
				   }
				   
				   System.out.print("\n"); 
			}
	}
}