import java.util.Scanner;

public class Pattern14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
	    Scanner Scan=new Scanner(System.in);
	    //asking the user to enter the number
	    System.out.println("Enter the value ");
	    int n=Scan.nextInt();
	     System.out.println("Enter the character need to be printed");
	     char ch=Scan.next().charAt(0);
			   //using for loop
		      for(int i=1;i<=n;i++)
			   {
				   for(int j=1;j<=n;j++)
				   {
					   System.out.print(" "); 
				   }
				   for(int j=1;j<=n;j++)
				   {
					   if(i==1||j==1 || i==n||j==n)
					   {
					   System.out.print(ch);
				       }
					   else				   
					   {
				         System.out.print(" "); 
			         
					   }
					 }
				   System.out.print("\n"); 
			}
	}

}

