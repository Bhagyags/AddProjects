import java.util.Scanner;

public class Pattern3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
		Scanner Scan=new Scanner(System.in);
	   //asking the user to enter the number
	   System.out.println("Enter the number of sides ");
	   int n=Scan.nextInt();
	   System.out.println("Enter the character need to be printed");
	   char ch=Scan.next().charAt(0);
	   //using for loop
	   /*for(int i=1;i<=n;i++)
	   {
		   for(int j=1;j<=n;j++)
		   {
		   System.out.print(ch); 
	   }
		   System.out.print("\n");   
	}*/
	   //using while loop
	  /* int i=1;
	   while(i<=n)
	   {
		   int j=1;
		   while(j<=n)
		   {
			   System.out.print(ch);
			   j++;
		   }
		   i++;
		   System.out.print("\n");
	   }*/
	   //using do while loop
	   int i=1;
	   do
	   {
		   int j=1;
		   do
		   {
			   System.out.print(ch);
			   j++;
		   }while(j<=n);
		   i++;
		   System.out.print("\n");
		   }
	   while(i<=n);
		   }
	}
