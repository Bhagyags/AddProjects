import java.util.Scanner;

public class Pattern13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
	    Scanner Scan=new Scanner(System.in);
	    //asking the user to enter the number
	    System.out.println("Enter the value ");
	    int n=Scan.nextInt();
	     System.out.println("Enter the character need to be printed");
	     char ch=Scan.next().charAt(0);
			   //using for loop
		for(int i=1;i<=n;i++)
			   {
				   for(int j=1;j<=n-i+1;j++)
				   {
					   System.out.print(" ");
				   }
				   for(int j=1;j<=i*2-1;j++)
				   {
				   System.out.print(ch); 
			   }
				   System.out.print("\n"); 
			}
		      for(int i=2;i<=n;i++)
		   {
			   for(int j=1;j<=i;j++)
			   {
				   System.out.print(" ");
			   }
			   for(int j=1;j<=11-(2*i);j++)
			   {
			   System.out.print(ch); 
		   }
			   System.out.print("\n"); 
		}

	}

}
