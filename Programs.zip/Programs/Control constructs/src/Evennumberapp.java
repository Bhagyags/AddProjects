
public class Evennumberapp {

	public static void getnum(int a) {
		// TODO Auto-generated method stub
		for(int i=1;i<=a;i++)
		{
if(i%2==0)
{
	System.out.println(i+"\t");
}
	}
}
}
