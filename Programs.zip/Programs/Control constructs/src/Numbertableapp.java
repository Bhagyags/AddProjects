
public class Numbertableapp {

	public static void getTable(int num) {
		// TODO Auto-generated method stub
for(int i=1;i<=10;i++)
{
	System.out.println(num+"*"+i+"="+num*i);
}
	}

}
