
public class Vendingmachineapp {

	public static void getProduct(int code) {
		// TODO Auto-generated method stub
		switch(code)
		{
		case 1:System.out.println("choclate");
		break;
		case 2:System.out.println("Biscuit");
		break;
		case 3:System.out.println("shampoo");
		break;
		case 4:System.out.println("Bananas");
		break;
		case 5:System.out.println("Apple");
		break;
		}

	}

}
