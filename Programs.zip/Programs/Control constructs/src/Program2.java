import java.util.Scanner;

public class Programs {
	public static void main(String []args)
	{
		//Creating the object of scanner class
		Scanner Scan=new Scanner(System.in);
		//Asking the user to enter the number
		System.out.println("Enter the number ");
		//Storing the number in variable num
		int num=Scan.nextInt();
		//Checking whether the number is in the range from 1 to 10
		if(num>=1 && num<=10)
		{
			System.out.println("Range 1");
		}
		//Checking whether the number is in the range from 11 to 20
		else if(num>=11 && num<=20)
		{
			System.out.println("Range 2");
		}
		//Checking whether the number is in the range from 21 to 30
		else if(num>=21 && num<=30)
		{
			System.out.println("Range 3");
		}
		//Checking whether the number is in the range from 31 to 40
		else if(num>=31 && num<=40)
		{
			System.out.println("Range 4");
		}
		//Checking whether the number is in the range from 41 to 50
		else if(num>=41 && num<=50)
		{
			System.out.println("Range 5");
		}
		//If the number is not in the range, printing outside range 
		else
		{
			System.out.println("Outside range");
		}
	}
}
