import java.util.Scanner;

public class Switchstatement {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
		Scanner Scan=new Scanner(System.in);
		System.out.println("Enter the First number");
		double num1=Scan.nextDouble();
		System.out.println("Enter the second number");
		double num2=Scan.nextDouble();
		System.out.println("Enter the Character");
		char operation=Scan.next().charAt(0);
		switch(operation)
		{
		case '+': System.out.println(num1+num2);
		          break;
		
		case '-': System.out.println(num1-num2);
		          break;
		
		case '*': System.out.println(num1*num2);
		          break;
		          
		case '/': System.out.println(num1/num2);
		          break;
		          
		default: System.out.println("Invalid input");
		  		}
		}
	}
