
public class Positiveapp {
	public static void getNum(int num)
	{
		if(num>0)
		{
			System.out.println("Positive number");
		}
	}

}
