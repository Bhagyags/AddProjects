
public class Vowelconsonantapp {

	public static void getVowel(char ch) {
		// TODO Auto-generated method stub
if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
{
	System.out.println("Entered character"+ch+"is lower case vowel");

}
else if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
{
	System.out.println("Entered character"+ch+"is upper case vowel");
}
else if(ch>='a' && ch<='z'){
	System.out.println("Entered character"+ch+"is lower case consonant");
}
else if(ch>='A' && ch<='Z'){
	System.out.println("Entered character"+ch+"is upper case consonant");
}
else if(ch>='0' && ch<='9'){
	System.out.println(ch+" is digit");
}
else {
	System.out.println("Special chracter");
}
}

}
