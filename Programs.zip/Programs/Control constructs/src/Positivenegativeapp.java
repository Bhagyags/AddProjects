import java.util.Scanner;

public class Positivenegativeapp {
public static void getNumber(int num)
{
	if(num>0)
	{
		System.out.println("Positive");
			
	}
	else
	{
		System.out.println("Negative");
	}
}
}
