import java.util.Scanner;

public class Calculator {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
		Scanner Scan=new Scanner(System.in);
		System.out.println("Enter the First number");
		double a=Scan.nextDouble();
		System.out.println("Enter the second number");
		double b=Scan.nextDouble();
		System.out.println("Enter the Character");
		char ch=Scan.next().charAt(0);
			if(ch=='+')
			{
				System.out.println(a+b);
			}
			else if(ch=='-')
			{
				System.out.println(a-b);
			}
			else if(ch=='*')
			{
				System.out.println(a*b);
			}
			else if(ch=='/')
			{
				System.out.println(a/b);
			}
			else
			{
				System.out.println("Invalid input");
			}
	}
}
