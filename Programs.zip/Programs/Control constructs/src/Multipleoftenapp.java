
public class Multipleoftenapp {
public static void getnum(int num)
{
	if(num%10==0)
	{
		System.out.println("multiple of 10");
	}
	else
	{
		System.out.println("Not multiple of 10");
	}
}
}
