import java.util.Scanner;

public class Program3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner Scan=new Scanner(System.in);
		System.out.println("Name of the user");
		String name=Scan.next();
		switch(name)
		{
		case "ajay":System.out.println("ajay ,Delhi");
		break;
		
		case "arjun":System.out.println("arjun ,Pune");
		break;
		
		case "ankith":System.out.println("ankith ,Bangalore");
		break;
		
		case "akash":System.out.println("akash ,Hyderabad");
		break;
		default:System.out.println("India");
		}
	}
}
