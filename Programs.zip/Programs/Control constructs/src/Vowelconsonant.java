import java.util.Scanner;

public class Vowelconsonant {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    //Creating the object of scanner class
	Scanner Scan=new Scanner(System.in);
    //asking the user to enter the character
    System.out.println("Enter the character");
    char ch=Scan.next().charAt(0);
    Vowelconsonantapp.getVowel(ch);
    	}

}
