import java.util.Scanner;

public class Numbertable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
		Scanner Scan=new Scanner(System.in);
	   //asking the user to enter the length
	   System.out.println("Enter the number");
	   int x=Scan.nextInt();
	   Numbertableapp.getTable(x);
	}

}
