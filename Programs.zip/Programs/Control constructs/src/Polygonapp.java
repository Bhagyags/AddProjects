
public class Polygonapp {

	public static void getsides(int side) {
		// TODO Auto-generated method stub
 if(side==5)
 {
	 System.out.println("Pentagon");
 }
 else if(side==4)
 {
	 System.out.println("Quadrilateral");

 }
 else if(side==3)
 {
	 System.out.println("Triangle");

 }
 else
 {
	 System.out.println("Polygon");

 }


	}

}
