import java.util.Scanner;

public class Positivenegative {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner Scan=new Scanner(System.in);
		System.out.println("Enter the Number");
		int x=Scan.nextInt();
		Positivenegativeapp.getNumber(x);
}
}
