import java.util.Scanner;

public class Peopleage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
		Scanner Scan=new Scanner(System.in);
		//asking the user to enter the number
		System.out.println("Enter the age");
		int x=Scan.nextInt();
		//calling the another class name
		Peopleageapp.getage(x);
	}
	}


