import java.util.Scanner;

public class Powercalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
		Scanner Scan=new Scanner(System.in);
	   //asking the user to enter the length
	   System.out.println("Enter the number");
	   int x=Scan.nextInt();
	   System.out.println("Enter the power");
	   int y=Scan.nextInt();
	   long r=1;
	   Powercalculatorapp.getPower(x,y);
	}

}
