import java.util.Scanner;

public class Program1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
		Scanner Scan=new Scanner(System.in);
		//Asking the user to enter the Character
        System.out .println("Enter the character");
      //Storing the number in variable 
        char ch=Scan.next().charAt(0);
        //Checking whether the character is upper case
        if(ch>='A' && ch<='Z')
        {
        	System.out.println("Upper case letter");
        }
      //Checking whether the character is Lower case
        else if(ch>='a' && ch<='z')
        {
        	System.out.println("Lower case letter");
        }
      //Checking whether the character is number
        else if(ch>='0' && ch<='9')
        {
        	System.out.println("It is a number");
        }
      //Checking whether the character is Special character
        else
        {
        	System.out.println("Special character");
        }
	}

}
