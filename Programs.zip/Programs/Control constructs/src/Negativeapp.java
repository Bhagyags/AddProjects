
public class Negativeapp {
public static void getint(int num)
{
	if(num>0)
	{
		System.out.println("Positive number");
	}
	else if(num<0)
	{
		System.out.println("Negative number");
	}
	else
	{
		System.out.println("Zero");
	}
}
}
