import java.util.Scanner;

public class Englishword {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner Scan=new Scanner(System.in);
		System.out.println("Enter the number");
		int num1=Scan.nextInt();
		switch(num1)
		{
		case 1:System.out.println("One");
        break;
        
case 2:System.out.println("Two");
        break;
        
case 3:System.out.println("Three");
       break;
       
case 4:System.out.println("Four");
break;

case 5:System.out.println("Five");
break;

default:System.out.println("Invalid Input");
		}
		}
	}
