import java.util.Scanner;

public class Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating the object of scanner class
				Scanner Scan=new Scanner(System.in);
			   //asking the user to enter the length
			   System.out.println("Enter the first number");
			   int x=Scan.nextInt();
			   System.out.println("Enter the second number");
			   int y=Scan.nextInt();
			   System.out.println("Enter the third number");
			   int z=Scan.nextInt();
			   //calling the another class name
			   Numbersapp.getnum(x,y,z);
	}

}
