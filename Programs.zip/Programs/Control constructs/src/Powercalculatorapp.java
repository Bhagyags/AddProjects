
public class Powercalculatorapp {

	public static void getPower(int num1,int num2) {
		// TODO Auto-generated method stub
		int z=1;
for(int i=1;i<=num2;i++)
{
	z=z*num1;
}
	System.out.println(z);
	}

}
