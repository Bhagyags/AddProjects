
public class Numbersapp {

	public static void getnum(int a,int b,int c) {
		// TODO Auto-generated method stub
if(a==b && b==c)
{
	System.out.println("All are equal");
}
else if(a>=b && a<=c)
{
	System.out.println(a+"largest number");

}
else if(b>=a && b<=c)
{
	System.out.println(b+"largest number");

}
else
{
	System.out.println(c+"largest number");

}
	}

}
