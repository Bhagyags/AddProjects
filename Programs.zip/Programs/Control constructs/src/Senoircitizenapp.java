
public class Senoircitizenapp {
public static void getmsg(int age)
{
	if(age>=60)
	{
		System.out.println("Eligible for senoir citizen discount");
	}
	else
	{
		System.out.println("Not Eligible for senoir citizen discount");
	}
}
}
