
public class Squareapp {

	public static void getmsg(int l,int b) {
		// TODO Auto-generated method stub
if(l==b)
{
	System.out.println("It is a square");
}
else
{
	System.out.println("It is not a square");
}
	}

}
