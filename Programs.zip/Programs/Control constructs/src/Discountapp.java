
public class Discountapp {
public static void msgdisplay(int num)
{
	if(num>=100)
	{
		System.out.println("Discount Applicable");
	}
}
}
