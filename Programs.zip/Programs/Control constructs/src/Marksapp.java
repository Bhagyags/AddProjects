
public class Marksapp {
public static void getmarks(int marks)
{
	if(marks>50)
	{
		System.out.println("Pass");
	}
	else {
		System.out.println("Fail");
	}
}
}
