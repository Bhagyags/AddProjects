import java.util.Scanner;

public class Calculatorswitch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			//Creating the object of scanner class
			Scanner Scan=new Scanner(System.in);
			System.out.println("Enter the First number");
			double a=Scan.nextDouble();
			System.out.println("Enter the second number");
			double b=Scan.nextDouble();
			System.out.println("Enter the Character");
			char operator=Scan.next().charAt(0);
					switch(operator)
					{
					case '+':System.out.println(a+b);
					break;
				
					case'-':System.out.println(a-b);
					break;
				
					case '*':System.out.println(a*b);
					break;
					
					case '/':System.out.println(a/b);
					break;
				default:System.out.println("Invalid input");
		}
}
}