
public class Naturalnumberapp {

	public static void getnum(int m) {
		// TODO Auto-generated method stub
		int n,num=0;
		while(m>0)
		{
			n=m%10;
			num=num+n;
			m=m/10;
	}
		System.out.println("Sum of digits: " +num);
	}
}
