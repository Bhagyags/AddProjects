package shadowsolution;

public class Studentshadowsln {
	 String name;
	  int age;
	  float percentage;
	  String Gender;
	  int rollno;
	  public Studentshadowsln(String name,int age,float percentage,String Gender,int rollno)
	  {
		 this.name=name;
		 this.age=age;
		 this.percentage=percentage;
		 this.Gender=Gender;
		 this.rollno=rollno;
	  }
	  void study()
	  {
		  System.out.println(name+" is studying");
		  System.out.println(name+" age is "+age);
	  }

}
