package shadowsolution;

import shadowproblem.Student;

public class Studentslnapp {

	public static void main(String[] args) {
		Studentshadowsln s1=new Studentshadowsln("rohit",22,83.5F,"male",30);
		s1.study();
		new Studentshadowsln("Rakesh",25,83.5F,"male",11).study();

	}

}
