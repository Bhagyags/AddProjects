
public class Students {
  String name;
  int age;
  float percentage;
  String Gender;
  int rollno;
  public Students(String a,int b,float c,String d,int e)
  {
	 name=a;
	 age=b;
	 percentage=c;
	 Gender=d;
	 rollno=e;
  }
  void study()
  {
	  System.out.println(name+" is studying");
  }

}
