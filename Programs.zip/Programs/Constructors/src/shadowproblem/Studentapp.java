package shadowproblem;

public class Studentapp {

	public static void main(String[] args) {
		Student s1=new Student("rohit",22,83.5F,"male",30);
		s1.study();
		new Student("Rakesh",25,83.5F,"male",11).study();
	}

}
