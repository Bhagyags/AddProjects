package shadowproblem;

public class Student {
	  String name;
	  int age;
	  float percentage;
	  String Gender;
	  int rollno;
	  public Student(String name,int age,float percentage,String Gender,int rollno)
	  {
		 name=name;
		 age=age;
		 percentage=percentage;
		 Gender=Gender;
		 rollno=rollno;
	  }
	  void study()
	  {
		  System.out.println(name+" is studying");
	  }

}
