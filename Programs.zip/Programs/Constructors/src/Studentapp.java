
public class Studentapp {

	public static void main(String[] args) {
		Students s1=new Students("rohit",22,83.5F,"male",30);
		s1.study();
		new Students("Rakesh",25,83.5F,"male",11).study();
	}

}
